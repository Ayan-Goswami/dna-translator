# DNA Translator (Python CLI)

A beginner-friendly educational bioinformatics project based on Project 01 in the uploaded *10 genetics projects you can build at home* PDF. The reference project asks for a standard genetic code built in code, longest ATG-to-stop ORF, frame and ORF length, with the HBB example expected to translate to a 147-amino-acid protein beginning `MVHLTPEEKSAVTALWGKV`.

## Requirements

- Python 3.9 or newer recommended
- No third-party packages required

## Files

- `dna_translator.py` — command-line application
- `test_dna_translator.py` — automated validation tests
- `hbb_coding.fasta` — HBB coding sequence from the supplied PDF

## Run it

Open a terminal in this folder.

### Translate a coding sequence

```bash
python dna_translator.py translate --sequence ATGGTGTAA
```

Expected protein: `MV` (the stop codon is not counted as an amino acid).

To show a `*` for a stop codon:

```bash
python dna_translator.py translate --sequence ATGGTGTAA --include-stop
```

### Translate from a FASTA file and save protein FASTA

```bash
python dna_translator.py translate --file hbb_coding.fasta --fasta hbb_protein.fasta --header human_beta_globin
```

### Search for ORFs

By default, the tool scans all six reading frames (three forward frames and three frames on the reverse-complement strand):

```bash
python dna_translator.py orf --file hbb_coding.fasta
```

To match the original PDF's three-forward-frame scope:

```bash
python dna_translator.py orf --file hbb_coding.fasta --forward-only
```

Save the longest ORF's protein sequence:

```bash
python dna_translator.py orf --file hbb_coding.fasta --fasta longest_orf.fasta
```

Coordinates are 1-based and inclusive on the strand being scanned. For the minus strand, coordinates are reported on the reverse-complement sequence, not mapped back to the original input coordinates.

### Show the codon table

```bash
python dna_translator.py codons
```

The table is generated in code from the four DNA bases and a standard 64-symbol amino-acid string. The six-codon amino-acid families should include leucine, serine, and arginine.

### Analyze possible single-base substitutions

```bash
python dna_translator.py mutations --file hbb_coding.fasta
```

Print each individual change:

```bash
python dna_translator.py mutations --file hbb_coding.fasta --details
```

Mutation analysis treats the input as a coding sequence beginning at its first base. It classifies changes as:
- **silent** — same amino acid
- **missense** — a different amino acid
- **nonsense** — a sense codon becomes a stop codon
- **stop_changed** — a substitution starts from an existing stop codon

The `stop_changed` category is reported separately so that mutations in the terminal stop codon do not get silently mixed into the three standard categories. Incomplete trailing bases are excluded.

## Run validation tests

```bash
python -m unittest -v
```

The tests check the 64-codon table, start/stop codons, sequence validation, reverse complement, translation, ORF detection, mutation-count arithmetic, and FASTA export.

## Biology and implementation notes

1. **Codons are triplets.** Translation reads bases in groups of three; changing the reading frame changes the codons.
2. **Start and stop codons.** This ORF finder looks for `ATG` and then a stop codon (`TAA`, `TAG`, or `TGA`) in the same frame.
3. **Six frames.** A double-stranded DNA molecule has three reading frames on each strand. The reverse complement is scanned to examine the other strand.
4. **ORF length.** The reported codon count includes the terminal stop codon; protein length excludes it.
5. **Standard genetic code.** The program uses the standard code and does not account for mitochondrial or other alternative genetic codes.
6. **Interpretation limits.** This is a learning project, not a validated clinical variant-analysis pipeline. ORF detection alone does not prove that a sequence is a biologically expressed gene.

## HBB validation target from the supplied PDF

For the HBB coding sequence in the reference PDF, the expected translation starts:

`MVHLTPEEKSAVTALWGKV`

The PDF specifies 444 bases, 148 codons including the stop codon, and 147 amino acids. The `translate` command translates the input from its first base; the `orf --forward-only` command searches for ATG-to-stop ORFs. These are related but distinct operations.
